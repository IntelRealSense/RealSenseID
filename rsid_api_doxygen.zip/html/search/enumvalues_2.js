var searchData=
[
  ['deviceerror_205',['DeviceError',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5abe252e5b290c865b4d033fe4c4f88e9a',1,'RealSenseID::DeviceError()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fabe252e5b290c865b4d033fe4c4f88e9a',1,'RealSenseID::DeviceError()']]],
  ['down_206',['Down',['../namespace_real_sense_i_d.html#a9f456249223fcfd654a9699c9d0186b1a08a38277b0309070706f6652eeae9a53',1,'RealSenseID']]]
];
