var searchData=
[
  ['nofacedetected_225',['NoFaceDetected',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5a4f10383c518354bb787f44cfa81593eb',1,'RealSenseID::NoFaceDetected()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa4f10383c518354bb787f44cfa81593eb',1,'RealSenseID::NoFaceDetected()']]]
];
