var searchData=
[
  ['authenticate_146',['Authenticate',['../class_real_sense_i_d_1_1_face_authenticator.html#ae73af75422d817b2aa9b876e540d9f1c',1,'RealSenseID::FaceAuthenticator']]],
  ['authenticateloop_147',['AuthenticateLoop',['../class_real_sense_i_d_1_1_face_authenticator.html#ad0a6b80eb6f0d8470574cc86e43a1d9a',1,'RealSenseID::FaceAuthenticator']]]
];
