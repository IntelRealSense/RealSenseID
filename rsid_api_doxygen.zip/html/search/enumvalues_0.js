var searchData=
[
  ['badframequality_201',['BadFrameQuality',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5ad2c0a4f3365aff3c279071abdd362056',1,'RealSenseID::BadFrameQuality()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fad2c0a4f3365aff3c279071abdd362056',1,'RealSenseID::BadFrameQuality()']]]
];
