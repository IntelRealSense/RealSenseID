var searchData=
[
  ['cancel_148',['Cancel',['../class_real_sense_i_d_1_1_face_authenticator.html#a1fc853634b72116f47d10f999e20193e',1,'RealSenseID::FaceAuthenticator']]],
  ['connect_149',['Connect',['../class_real_sense_i_d_1_1_device_controller.html#aa2317464614501ad62e15093d333ea86',1,'RealSenseID::DeviceController::Connect()'],['../class_real_sense_i_d_1_1_face_authenticator.html#ad8631174408bb93f0cd0417460a356bf',1,'RealSenseID::FaceAuthenticator::Connect()']]]
];
