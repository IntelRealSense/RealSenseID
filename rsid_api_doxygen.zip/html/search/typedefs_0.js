var searchData=
[
  ['camerarotationtype_194',['CameraRotationType',['../struct_real_sense_i_d_1_1_auth_config.html#a1c926477d5d2bcbd94432b14cea57a67',1,'RealSenseID::AuthConfig']]]
];
