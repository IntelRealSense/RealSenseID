var searchData=
[
  ['camera_5frotation_181',['camera_rotation',['../struct_real_sense_i_d_1_1_auth_config.html#a8fd20093aadb67d36a0156d0155d557b',1,'RealSenseID::AuthConfig']]],
  ['cameranumber_182',['cameraNumber',['../struct_real_sense_i_d_1_1_preview_config.html#a9f83668aa79582e5cc708436eadc7f8b',1,'RealSenseID::PreviewConfig']]]
];
