var searchData=
[
  ['faceauthenticator_123',['FaceAuthenticator',['../class_real_sense_i_d_1_1_face_authenticator.html',1,'RealSenseID']]]
];
