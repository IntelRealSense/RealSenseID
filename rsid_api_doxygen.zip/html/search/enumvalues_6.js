var searchData=
[
  ['multiplefacesdetected_224',['MultipleFacesDetected',['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa0fa1ad39282c21909548c8375ab5a2bd',1,'RealSenseID']]]
];
