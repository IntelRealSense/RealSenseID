var searchData=
[
  ['verify_171',['Verify',['../class_real_sense_i_d_1_1_signature_callback.html#a563142ef3264ac71192e6ee642b23c66',1,'RealSenseID::SignatureCallback']]],
  ['version_172',['Version',['../namespace_real_sense_i_d.html#a297fa3e92999f9ee05c1797dec1a126a',1,'RealSenseID']]]
];
