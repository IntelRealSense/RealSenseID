var searchData=
[
  ['serialconfig_128',['SerialConfig',['../struct_real_sense_i_d_1_1_serial_config.html',1,'RealSenseID']]],
  ['signaturecallback_129',['SignatureCallback',['../class_real_sense_i_d_1_1_signature_callback.html',1,'RealSenseID']]]
];
