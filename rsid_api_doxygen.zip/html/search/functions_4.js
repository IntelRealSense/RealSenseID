var searchData=
[
  ['faceauthenticator_154',['FaceAuthenticator',['../class_real_sense_i_d_1_1_face_authenticator.html#aa228e5a76efc818c7ef6a4fabfa2bf90',1,'RealSenseID::FaceAuthenticator::FaceAuthenticator(SignatureCallback *callback)'],['../class_real_sense_i_d_1_1_face_authenticator.html#a576226a0c922d18d12202b0b9ed7f42f',1,'RealSenseID::FaceAuthenticator::FaceAuthenticator(const FaceAuthenticator &amp;)=delete']]]
];
