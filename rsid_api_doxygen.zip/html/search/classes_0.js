var searchData=
[
  ['authconfig_119',['AuthConfig',['../struct_real_sense_i_d_1_1_auth_config.html',1,'RealSenseID']]],
  ['authenticationcallback_120',['AuthenticationCallback',['../class_real_sense_i_d_1_1_authentication_callback.html',1,'RealSenseID']]]
];
