var searchData=
[
  ['camera_5frotation_10',['camera_rotation',['../struct_real_sense_i_d_1_1_auth_config.html#a8fd20093aadb67d36a0156d0155d557b',1,'RealSenseID::AuthConfig']]],
  ['cameranumber_11',['cameraNumber',['../struct_real_sense_i_d_1_1_preview_config.html#a9f83668aa79582e5cc708436eadc7f8b',1,'RealSenseID::PreviewConfig']]],
  ['camerarotationtype_12',['CameraRotationType',['../struct_real_sense_i_d_1_1_auth_config.html#a1c926477d5d2bcbd94432b14cea57a67',1,'RealSenseID::AuthConfig']]],
  ['camerastarted_13',['CameraStarted',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5a80ae02249747bf0d20896da4a254a05b',1,'RealSenseID::CameraStarted()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa80ae02249747bf0d20896da4a254a05b',1,'RealSenseID::CameraStarted()']]],
  ['camerastopped_14',['CameraStopped',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5a6efbc738e4e363d3f5cba7b9074a0651',1,'RealSenseID::CameraStopped()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa6efbc738e4e363d3f5cba7b9074a0651',1,'RealSenseID::CameraStopped()']]],
  ['cancel_15',['Cancel',['../class_real_sense_i_d_1_1_face_authenticator.html#a1fc853634b72116f47d10f999e20193e',1,'RealSenseID::FaceAuthenticator']]],
  ['center_16',['Center',['../namespace_real_sense_i_d.html#a9f456249223fcfd654a9699c9d0186b1a4f1f6016fc9f3f2353c0cc7c67b292bd',1,'RealSenseID']]],
  ['connect_17',['Connect',['../class_real_sense_i_d_1_1_device_controller.html#aa2317464614501ad62e15093d333ea86',1,'RealSenseID::DeviceController::Connect()'],['../class_real_sense_i_d_1_1_face_authenticator.html#ad8631174408bb93f0cd0417460a356bf',1,'RealSenseID::FaceAuthenticator::Connect()']]]
];
