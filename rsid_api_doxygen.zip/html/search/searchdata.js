var indexSectionsWithContent =
{
  0: "abcdefhilmnoprsuvw~",
  1: "adefips",
  2: "r",
  3: "adefprsv",
  4: "acdefoprsv~",
  5: "bcdhnprsw",
  6: "cs",
  7: "aefs",
  8: "bcdeflmnorsu",
  9: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

