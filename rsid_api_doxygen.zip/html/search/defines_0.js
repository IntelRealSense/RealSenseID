var searchData=
[
  ['rsid_5fapi_236',['RSID_API',['../_real_sense_i_d_exports_8h.html#a2192929bfc0580a9c191338cbaa765df',1,'RealSenseIDExports.h']]],
  ['rsid_5fver_5fmajor_237',['RSID_VER_MAJOR',['../_version_8h.html#a4830da90ac0b6a3c42f31dd91aed6015',1,'Version.h']]],
  ['rsid_5fver_5fminor_238',['RSID_VER_MINOR',['../_version_8h.html#a8a66f2eb5795443d8591481847b97365',1,'Version.h']]],
  ['rsid_5fver_5fpatch_239',['RSID_VER_PATCH',['../_version_8h.html#a1e0fd8d10e39a45812498b9e964b3d79',1,'Version.h']]],
  ['rsid_5fversion_240',['RSID_VERSION',['../_version_8h.html#ac689e506b230cdf60861cda4dca02dcf',1,'Version.h']]]
];
