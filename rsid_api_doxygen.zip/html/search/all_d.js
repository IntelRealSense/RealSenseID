var searchData=
[
  ['readme_2emd_70',['Readme.md',['../_readme_8md.html',1,'']]],
  ['realsenseid_71',['RealSenseID',['../namespace_real_sense_i_d.html',1,'']]],
  ['realsenseidexports_2eh_72',['RealSenseIDExports.h',['../_real_sense_i_d_exports_8h.html',1,'']]],
  ['reboot_73',['Reboot',['../class_real_sense_i_d_1_1_device_controller.html#a56cf55256b347b9d16c2fbc1591b2a29',1,'RealSenseID::DeviceController']]],
  ['removeall_74',['RemoveAll',['../class_real_sense_i_d_1_1_face_authenticator.html#a27e2fbdd5ce24de30b121dec9d841d6a',1,'RealSenseID::FaceAuthenticator']]],
  ['removeuser_75',['RemoveUser',['../class_real_sense_i_d_1_1_face_authenticator.html#a6bef2263f2a1a2f3261b8adb21e21563',1,'RealSenseID::FaceAuthenticator']]],
  ['resumepreview_76',['ResumePreview',['../class_real_sense_i_d_1_1_preview.html#ac7209352860bde1f20dcf9b987f086de',1,'RealSenseID::Preview']]],
  ['right_77',['Right',['../namespace_real_sense_i_d.html#a9f456249223fcfd654a9699c9d0186b1a92b09c7c48c520c3c55e497875da437c',1,'RealSenseID']]],
  ['rotation_5f90_5fdeg_78',['Rotation_90_Deg',['../_auth_config_8h.html#a32f03ee441dabfcb76e9d17c2cad9f58',1,'AuthConfig.h']]],
  ['rsid_5fapi_79',['RSID_API',['../_real_sense_i_d_exports_8h.html#a2192929bfc0580a9c191338cbaa765df',1,'RealSenseIDExports.h']]],
  ['rsid_5fver_5fmajor_80',['RSID_VER_MAJOR',['../_version_8h.html#a4830da90ac0b6a3c42f31dd91aed6015',1,'Version.h']]],
  ['rsid_5fver_5fminor_81',['RSID_VER_MINOR',['../_version_8h.html#a8a66f2eb5795443d8591481847b97365',1,'Version.h']]],
  ['rsid_5fver_5fpatch_82',['RSID_VER_PATCH',['../_version_8h.html#a1e0fd8d10e39a45812498b9e964b3d79',1,'Version.h']]],
  ['rsid_5fversion_83',['RSID_VERSION',['../_version_8h.html#ac689e506b230cdf60861cda4dca02dcf',1,'Version.h']]]
];
