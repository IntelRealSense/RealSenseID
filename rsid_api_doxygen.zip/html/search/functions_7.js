var searchData=
[
  ['reboot_163',['Reboot',['../class_real_sense_i_d_1_1_device_controller.html#a56cf55256b347b9d16c2fbc1591b2a29',1,'RealSenseID::DeviceController']]],
  ['removeall_164',['RemoveAll',['../class_real_sense_i_d_1_1_face_authenticator.html#a27e2fbdd5ce24de30b121dec9d841d6a',1,'RealSenseID::FaceAuthenticator']]],
  ['removeuser_165',['RemoveUser',['../class_real_sense_i_d_1_1_face_authenticator.html#a6bef2263f2a1a2f3261b8adb21e21563',1,'RealSenseID::FaceAuthenticator']]],
  ['resumepreview_166',['ResumePreview',['../class_real_sense_i_d_1_1_preview.html#ac7209352860bde1f20dcf9b987f086de',1,'RealSenseID::Preview']]]
];
