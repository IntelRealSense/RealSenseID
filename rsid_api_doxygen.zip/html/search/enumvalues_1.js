var searchData=
[
  ['camerastarted_202',['CameraStarted',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5a80ae02249747bf0d20896da4a254a05b',1,'RealSenseID::CameraStarted()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa80ae02249747bf0d20896da4a254a05b',1,'RealSenseID::CameraStarted()']]],
  ['camerastopped_203',['CameraStopped',['../namespace_real_sense_i_d.html#a1d136c7eeb7aa65d8c070d0b72c27fb5a6efbc738e4e363d3f5cba7b9074a0651',1,'RealSenseID::CameraStopped()'],['../namespace_real_sense_i_d.html#a84be98d6bf93d3207fd757e63e63ed8fa6efbc738e4e363d3f5cba7b9074a0651',1,'RealSenseID::CameraStopped()']]],
  ['center_204',['Center',['../namespace_real_sense_i_d.html#a9f456249223fcfd654a9699c9d0186b1a4f1f6016fc9f3f2353c0cc7c67b292bd',1,'RealSenseID']]]
];
