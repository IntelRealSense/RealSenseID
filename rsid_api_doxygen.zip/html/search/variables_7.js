var searchData=
[
  ['security_5flevel_189',['security_level',['../struct_real_sense_i_d_1_1_auth_config.html#aea0fd70a58ba0c5d076a9b53416566b2',1,'RealSenseID::AuthConfig']]],
  ['sertype_190',['serType',['../struct_real_sense_i_d_1_1_serial_config.html#aeac69019f9723bb8864d50ab4d8ef554',1,'RealSenseID::SerialConfig']]],
  ['size_191',['size',['../struct_real_sense_i_d_1_1_image.html#a7d1135ffbf5b5fb753859b9c430d7c40',1,'RealSenseID::Image']]],
  ['stride_192',['stride',['../struct_real_sense_i_d_1_1_image.html#a2da5e2f3cb66fc118599f83fc7a19507',1,'RealSenseID::Image']]]
];
